import React from "react";

function Header() {
  return (
    <header>
      <h1>Disney Fictional Characters</h1>
    </header>
  );
}

export default Header;
