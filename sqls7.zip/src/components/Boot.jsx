import React from "react";

function Boot() {
  return (
    <div className="note">
      <h1>Elsa</h1>
      <p>
        She is introduced as a princess in the fictional Scandinavian Kingdom of
        Arendelle, heiress to the throne and the elder sister of Princess Anna.
        Elsa has the magical ability to create and manipulate ice and snow.
      </p>
    </div>
  );
}

export default Boot;
